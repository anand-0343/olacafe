﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OLACafe.Service.Foods;

namespace OLACafeAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class FoodsController : Controller
    {
        private readonly IFoodTypeService foodTypeService;
        private readonly IFoodService foodService;

        public FoodsController(IFoodService foodService,IFoodTypeService foodTypeService)
        {
            this.foodService = foodService;
            this.foodTypeService = foodTypeService;
        }

       
        public async Task<IActionResult> GetAllFoods()
        {
            var foods = await foodService.GetAllFoodsAsync();
            return Json(new { isSuccess = true ,data=foods}) ;
        }

        public async Task<IActionResult> GetFoodsByType(long id )
        {
            var foodType = await foodService.GetAllFoodsByFoodTypeIdAsync(id);

            return Json(new { iSuccess = true, data = foodType });
        }
        
    }
}