﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OLACafe.Data.Entities.ShoppingCarts.Dto
{
    public class ShoppingCartDto
    {

    }
}
