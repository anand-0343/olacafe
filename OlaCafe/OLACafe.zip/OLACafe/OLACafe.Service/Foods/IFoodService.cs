﻿using OLACafe.Data.Entities.Foods;
using OLACafe.Data.Entities.Foods.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OLACafe.Service.Foods
{
    public interface IFoodService
    {
        Task<IList<FoodListingViewModel>> GetAllFoodsAsync();
        Task<IList<Food>> GetAllFoodsByFoodTypeIdAsync(long foodTypeId);

        Task<Food> GetFoodByIdAsync(long id);
    }
}
