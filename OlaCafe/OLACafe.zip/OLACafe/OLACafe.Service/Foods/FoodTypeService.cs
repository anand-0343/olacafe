﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OLACafe.Data.Entities.Foods;
using OLACafe.Repository;

namespace OLACafe.Service.Foods
{
    public class FoodTypeService : IFoodTypeService
    {
        private readonly IRepository<FoodType> _repository;

        public FoodTypeService(IRepository<FoodType> repository)
        {
            this._repository = repository;
        }
        public async Task<IList<FoodType>> GetAvailableFoodTypesAsync()
        {
            var foods =await  _repository.GetAll().ToListAsync();
            return foods;
        }

        public async Task<FoodType> GetFoodTypeByIdAsync(long id)
        {
            var food = await _repository.GetAll()
                 .FirstOrDefaultAsync(q => q.Id == id);
            return food;
        }

     
    }
}
