﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FoodDelivery.Core.Extensions;
using Microsoft.EntityFrameworkCore;
using OLACafe.Data.Entities.Foods;
using OLACafe.Data.Entities.Foods.ViewModels;
using OLACafe.Repository;


namespace OLACafe.Service.Foods
{
    public class FoodService : IFoodService
    {
        private readonly IRepository<Food> _repository;

        public FoodService(IRepository<Food> repositoryFood)
        {
            this._repository = repositoryFood;
        }
        public async Task<IList<FoodListingViewModel>> GetAllFoodsAsync()
        {
            var foods = await _repository.GetAll().ToListAsync();
            var foodlisting = new List<FoodListingViewModel>();

            foreach(var food in foods)
            {
                foodlisting.Add(new FoodListingViewModel
                {
                    Id = food.Id,
                    Name = food.Name,
                    ImageUrl = food.ImageUrl,
                    SeoFriendlyUrl = food.Name.SeoFriendlyUrl()
                });
            }
            return foodlisting;

        }

        public async Task<IList<Food>> GetAllFoodsByFoodTypeIdAsync(long foodTypeId)
        {
            var food = await _repository.GetAll()
                 .Where(q => q.FoodType.Id == foodTypeId)
                 .ToListAsync();

            return food;
        }

        public async Task<Food> GetFoodByIdAsync(long id)
        {
            var food = await _repository.GetAll()
                 .FirstOrDefaultAsync(q => q.Id == id);

            return food;
        }
    }
}
