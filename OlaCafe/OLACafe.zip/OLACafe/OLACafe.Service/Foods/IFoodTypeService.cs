﻿using OLACafe.Data.Entities.Foods;
using OLACafe.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OLACafe.Service.Foods
{
   public interface IFoodTypeService
    {
      

        Task<IList<FoodType>> GetAvailableFoodTypesAsync();
        Task<FoodType> GetFoodTypeByIdAsync(long id);
    }
}
